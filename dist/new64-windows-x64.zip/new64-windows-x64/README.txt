new64 -- Super Mario 64's movement model in a custom engine
===========================================================

Windows x64. Three files, no installer, no DLLs to copy. Unzip anywhere and
double-click new64_play.exe.

If SmartScreen warns you: the binaries are unsigned (code signing certificates
cost money). Click "More info" then "Run anyway", or right-click the exe ->
Properties -> Unblock. If you would rather not trust a binary from a stranger,
build it yourself -- the source is on GitHub and needs nothing but a compiler.


CONTROLS
--------
Keyboard:
  WASD / arrows   move
  Space           A -- jump
  J               B -- punch, or dive when running
  K or Shift      Z -- crouch, ground pound, long jump
  Q / E           rotate camera
  R               reset to spawn
  Esc             quit

Xbox-style gamepad (plug it in, it is picked up automatically):
  Left stick      move
  A               jump
  X or B          punch / dive
  Triggers or bumpers   Z
  Right stick     rotate camera
  Back            reset

USE A GAMEPAD IF YOU HAVE ONE. This is not a comfort preference. The stick
response is quadratic -- half deflection gives a quarter speed -- so the whole
low end of the curve (creeping, walking, the tiptoe) only exists with an analog
stick. On a keyboard you always get full deflection and the character always
runs.


THINGS TO TRY
-------------
  Run, then tap Space each time you land        single -> double -> triple jump
  Run, then slam the stick the OTHER way        skid turn, then a full reversal
  Press Space DURING that turn                  side flip (launches at 62)
  Hold K, then Space                            backflip
  Run, tap K, then Space                        long jump (low, very far)
  Run at a wall, jump, tap Space on contact     wall kick (2-frame window!)
  Run and press J                               dive, then a long slide
  Jump and press K                              ground pound
  Walk onto the pale blue ice and let go        watch how long it takes to stop
  Jump at a ledge you cannot quite clear        ledge grab, then Space to climb

The level is a test rig, not a scene. Every feature exists to exercise one
mechanic. Heading out from the spawn:

  north       open runway, then a row of platforms with gaps of 500, 700, 900
              and 1100. A running jump clears the first; only a long jump
              clears the last.
  south       the slope ladder: ramps at 10, 20, 30 and 45 degrees, plus the
              same 20-degree pitch in slippery and icy variants. 20 degrees is
              walkable on grass and unstandable on ice -- steepness is a
              property of the surface type, not the geometry.
  west        three wall-kick shafts, 300 / 450 / 600 units across, plus an
              offset pair of walls set further apart. Width is the difficulty:
              after a kick you cross at about 25 units a frame while the kick
              buys roughly 13 frames of rise.
  east        stairs rising 60 to 360 a step (the short ones are walked over
              without leaving the ground, the tall ones need a jump), a step
              tower, a ledge-grab face, and a tunnel too low to walk through
              (crawl with K).
  northwest   a cluster of platforms at assorted heights, no intended route --
              for feeling out jump distances.

Surface colours are a legend: green is normal ground, pale blue is ice
(very slippery), blue is slippery, sand is speed-capped, brown is stone.


THE OTHER TWO EXECUTABLES
-------------------------
new64_tests.exe       163 assertions covering the collision substrate, every
                      movement constant (jump launch velocities, terminal
                      velocity, speed caps, slope thresholds, the jump chain,
                      the wall kick window, the stick-to-world mapping) and the
                      level's own geometry. Run it from a terminal.

new64_headless.exe    Replays deterministic input scripts and writes a
                      per-frame state trace plus rendered PNG frames and an
                      animated GIF. This is how the engine is verified, since
                      movement is a time-domain property you cannot judge from
                      a screenshot. From a terminal:

                        new64_headless.exe --list
                        new64_headless.exe --script jumpchain --out out
                        new64_headless.exe --script tour --out out --trace t.txt

                      Built-in scripts: walk, jumpchain, jumpheight, longjump,
                      wallkick, wallshafts, turnaround, sideflip, backflip,
                      slopes, ice, dive, groundpound, ledgegrab, tour.


A NOTE ON FIDELITY
------------------
The movement is a from-scratch reimplementation written to match the original's
documented behaviour -- the same constants, the same state machine shape, and
the same substrate quirks that most of the feel actually comes from (collision
positions truncated to 16-bit integers, four collision sub-steps per frame, a
78-unit step-up allowance, 4096-entry angle tables). It is not a byte-for-byte
copy of anyone's code, and the parts that are reconstruction rather than
certainty are flagged in the source.

Physics runs at a fixed 30Hz and is frame-rate dependent by design: gravity is
"-4 per frame", not per second. The window paces itself to 30Hz rather than
scaling by delta time, because scaling would be wrong.

Source, full documentation and the test suite:
  https://github.com/esotericode/new64
